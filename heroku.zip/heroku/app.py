from flask import Flask
import pickle
import xgboost as xgb
from xgboost.sklearn import XGBRegressor
from sklearn.linear_model import Lasso
import pandas as pd
import numpy as np
from flask import request
from flask import render_template
from model import Reg_model
from dateutil.parser import parse


app = Flask(__name__,template_folder='templates')


filehandler = open('model.pickle', 'rb')
model = pickle.load(filehandler)
# print(model.__module__)
filehandler.close()

@app.route("/")
def predict():
	return render_template('index.html')
 
@app.route('/house')
def house_price():
    # show the user profile for that user
	full_sq  = request.args.get('full_sq')
	floor = request.args.get('floor')
	build_year = request.args.get('build_year')
	max_floor = request.args.get('max_floor')
	data = pd.DataFrame({'full_sq':[full_sq], 'floor':[floor],                                     'build_year':[build_year], 'max_floor':[max_floor]},dtype = np.float64)
	print(data.dtypes) 
	pred_val = model.predict(data)
	return render_template('predict.html', price=pred_val[0])
if __name__ == "__main__":
	app.run()
