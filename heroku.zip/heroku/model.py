from sklearn.base import TransformerMixin
from sklearn.linear_model import Lasso
class Reg_model(TransformerMixin):
    def fit(self, X, y):
        regressor = Lasso()
        data = X[['full_sq']]

        parameters = {'alpha': np.linspace(0.01, 90, 100)}
        clf = GridSearchCV(regressor, parameters)
        clf.fit(data, train[target])
        alfa = clf.best_params_['alpha']

        regressor = Lasso(alpha = alfa)
        self.reg = regressor.fit(data, y)
        return self
    
    def transform(self, X, y= None):
        data = X[['full_sq']]
        self.price = self.reg.predict(data)
        X['linear_price'] = self.price
        return X
   
